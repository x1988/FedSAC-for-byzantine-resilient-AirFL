
This is an implementation of the following paper:
**Byzantine-Resilient Over-the-Air Federated Learning under Zero-Trust Architecture**  


Our implementation adopts the implementation in https://github.com/yjlee22/FedShare as the code base and have extensively modified it to our purposes. We thank the authors for sharing their codes.
